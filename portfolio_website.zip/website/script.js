// JavaScript for interactive behaviour on the portfolio website.
// Handles the burger menu for small screens, simple contact form
// feedback, and reveals timeline items as the user scrolls.

document.addEventListener('DOMContentLoaded', () => {
  const burger = document.getElementById('burger');
  const navLinks = document.getElementById('navLinks');
  const form = document.getElementById('contactForm');
  const formResponse = document.getElementById('formResponse');

  // Toggle navigation on burger click
  burger.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    burger.classList.toggle('open');
  });

  // Simple form handler: display a friendly message on submit
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      formResponse.textContent = 'Thank you for your message! I will get back to you soon.';
      form.reset();
    });
  }

  // Intersection Observer to reveal timeline items on scroll
  const timelineItems = document.querySelectorAll('.timeline-item');
  const observerOptions = {
    root: null,
    threshold: 0.1
  };
  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);
  timelineItems.forEach(item => observer.observe(item));
});